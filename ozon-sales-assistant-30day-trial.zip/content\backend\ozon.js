// Ozon Sales Assistant Plugin
// Clean and readable implementation

(function() {
    'use strict';

    class OzonSalesAssistant {
        constructor() {
            console.log('🚀 OZON销量助手插件开始初始化...');
            this.sysLang = this.getCookie('x-o3-language') || 'zh';
            this.trialPeriodMinutes = 30 * 24 * 60; // 试用期30天（一个月）
            console.log('⏰ 试用期设置为:', this.trialPeriodMinutes, '分钟 (30天)');
            
            // 标记插件已初始化
            window.ozonAssistantInitialized = true;
            
            this.init();
        }

        // Cookie management
        getCookie(name) {
            if (document.cookie.length > 0) {
                let start = document.cookie.indexOf(name + '=');
                if (start !== -1) {
                    start = start + name.length + 1;
                    let end = document.cookie.indexOf(';', start);
                    if (end === -1) end = document.cookie.length;
                    return unescape(document.cookie.substring(start, end));
                }
            }
            return '';
        }

        // 设置Cookie
        setCookie(name, value, days, domain) {
            let expires = '';
            if (days) {
                const date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = '; expires=' + date.toUTCString();
            }
            const domainStr = domain ? '; domain=' + domain : '';
            document.cookie = name + '=' + (value || '') + expires + '; path=/' + domainStr;
        }

        // 获取系统当前时间戳（更可靠的时间获取方式）
        getSystemTimestamp() {
            // 使用Performance API获取更精确的时间
            const performanceNow = performance.now();
            const performanceStart = performance.timeOrigin || performance.timing.navigationStart;
            return Math.floor(performanceStart + performanceNow);
        }

        // 检查试用期（测试版本：30天）
        checkTrialPeriod() {
            console.log('🔍 开始检查试用期状态...');
            const installDate = this.getCookie('ozon_plugin_install_date');
            const currentTimestamp = this.getSystemTimestamp();
            
            console.log('🕐 系统当前时间:', new Date(currentTimestamp));
            
            // 如果没有安装日期，设置当前系统时间为安装日期
            if (!installDate) {
                console.log('📅 首次使用，设置安装时间:', new Date(currentTimestamp));
                // 设置Cookie过期时间为365天，确保持久保存
                this.setCookie('ozon_plugin_install_date', currentTimestamp.toString(), 365, '.ozon.ru');
                return true;
            }
            
            const installTimestamp = parseInt(installDate);
            console.log('📅 安装时间:', new Date(installTimestamp));
            
            // 计算已使用分钟数（基于系统时间）
            const minutesPassed = Math.floor((currentTimestamp - installTimestamp) / (1000 * 60));
            const remainingMinutes = this.trialPeriodMinutes - minutesPassed;
            
            console.log('⏱️ 已使用时间:', Math.floor(minutesPassed/1440), '天，剩余时间:', Math.floor(remainingMinutes/1440), '天');
            console.log('🔢 时间差计算:', (currentTimestamp - installTimestamp), '毫秒');
            
            // 检查是否超过试用期（绝对不受刷新影响）
            if (minutesPassed >= this.trialPeriodMinutes) {
                console.log('❌ 试用期已结束');
                console.log('🚨 试用期过期，显示过期弹窗');
                this.showTrialExpiredModal();
                return false;
            }
            
            // 如果还有1分钟或更少时间，显示提醒（绝对不受刷新影响）
            if (remainingMinutes <= 2) {
                console.log('⚠️ 试用期即将结束，显示提醒');
                this.showTrialReminderModal(remainingMinutes);
            }
            
            return true;
        }

        // 显示试用期过期弹窗（测试版本）- 原生JavaScript实现
        showTrialExpiredModal() {
            console.log('🚨 显示试用期过期弹窗');
            
            const modal = document.createElement('div');
            modal.id = 'trial-expired-modal';
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.7);
                z-index: 999999;
                display: flex;
                justify-content: center;
                align-items: center;
                font-family: Arial, sans-serif;
            `;
            
            modal.innerHTML = `
                <div style="
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    max-width: 500px;
                    text-align: center;
                    position: relative;
                    border: 2px solid #e74c3c;
                ">
                    <h2 style="color: #e74c3c; margin-bottom: 20px; font-size: 24px;">⚠️ 测试版本已结束</h2>
                    <div style="margin-bottom: 20px; line-height: 1.6; color: #666;">
                        <p style="margin-bottom: 15px; font-size: 16px;">感谢您使用OZON销量助手插件！</p>
                        <p style="margin-bottom: 20px; font-size: 14px;">您的30天试用版本已结束，如需正式版本请联系NICOLE进行购买。</p>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: left;">
                          
                        </div>
                        <div style="text-align: center; margin: 20px 0;">
                            <p style="font-weight: bold; margin-bottom: 10px;">购买正式版本请联系：</p>
                            <p style="font-size: 16px; color: #2c3e50; background: #ecf0f1; padding: 10px; border-radius: 5px; margin: 10px 0;">微信：ZQF13532538910</p>
                        </div>
                    </div>
                    <button id="trialExpiredOkBtn" style="
                        background: linear-gradient(45deg, #e74c3c 0%, #c0392b 100%);
                        color: white;
                        border: none;
                        padding: 12px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: bold;
                        transition: transform 0.2s;
                        margin-right: 10px;
                    ">我知道了</button>
                    <button id="trialExpiredCloseBtn" style="
                        background: #95a5a6;
                        color: white;
                        border: none;
                        padding: 12px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: bold;
                        transition: transform 0.2s;
                    ">关闭</button>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // 按钮点击事件
            document.getElementById('trialExpiredOkBtn').onclick = () => {
                document.body.removeChild(modal);
                // 禁用插件功能
                this.disablePlugin();
            };
            
            document.getElementById('trialExpiredCloseBtn').onclick = () => {
                document.body.removeChild(modal);
                // 禁用插件功能
                this.disablePlugin();
            };
            
            // 阻止点击背景关闭（强制用户确认）
            modal.onclick = (e) => {
                e.stopPropagation();
            };
        }
        
        // 禁用插件功能
        disablePlugin() {
            console.log('🔒 插件功能已禁用');
            // 可以在这里添加禁用插件功能的逻辑
            window.ozonPluginDisabled = true;
        }



        // 显示试用期提醒弹窗（测试版本：30天）- 原生JavaScript实现
        showTrialReminderModal(remainingMinutes) {
            console.log(`⏰ 显示试用期提醒弹窗，剩余时间: ${Math.floor(remainingMinutes/1440)} 天`);
            
            const modal = document.createElement('div');
            modal.id = 'trial-reminder-modal';
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.7);
                z-index: 999999;
                display: flex;
                justify-content: center;
                align-items: center;
                font-family: Arial, sans-serif;
            `;
            
            modal.innerHTML = `
                <div style="
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    max-width: 500px;
                    text-align: center;
                    position: relative;
                    border: 2px solid #f39c12;
                    animation: slideInFromTop 0.5s ease-out;
                ">
                    <h2 style="color: #f39c12; margin-bottom: 20px; font-size: 24px;">⏰ 测试版本即将结束</h2>
                    <div style="margin-bottom: 20px; line-height: 1.6; color: #666;">
                        <p style="margin-bottom: 15px; font-size: 16px;">您的OZON销量助手插件（测试版）还有 <strong style="color: #e74c3c; font-size: 18px;">${Math.floor(remainingMinutes/1440)}</strong> 天试用期</p>
                        <p style="margin-bottom: 20px; font-size: 14px;">这是30天试用版本，如需正式版本请联系NICOLE。</p>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: left;">
                            <p style="margin: 0; font-weight: bold; text-align: center;">联系方式：</p>
                            <p style="margin: 5px 0;">📧 邮箱: zouqifeng@jiawae-commerce.com</p>
                           
                        </div>
                        <div style="text-align: center; margin: 20px 0;">
                            <p style="font-weight: bold; margin-bottom: 10px;">购买正式版本请联系：</p>
                            <p style="font-size: 16px; color: #2c3e50; background: #ecf0f1; padding: 10px; border-radius: 5px; margin: 10px 0;">微信：ZQF13532538910</p>
                        </div>
                    </div>
                    <button id="trialReminderOkBtn" style="
                        background: linear-gradient(45deg, #f39c12 0%, #e67e22 100%);
                        color: white;
                        border: none;
                        padding: 12px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: bold;
                        transition: transform 0.2s;
                        margin-right: 10px;
                    ">我知道了</button>
                    <button id="trialReminderCloseBtn" style="
                        background: #95a5a6;
                        color: white;
                        border: none;
                        padding: 12px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: bold;
                        transition: transform 0.2s;
                    ">关闭</button>
                </div>
            `;
            
            // 添加CSS动画
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideInFromTop {
                    0% {
                        transform: translateY(-100px);
                        opacity: 0;
                    }
                    100% {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }
            `;
            document.head.appendChild(style);
            
            document.body.appendChild(modal);
            
            // 按钮点击事件
            document.getElementById('trialReminderOkBtn').onclick = () => {
                document.body.removeChild(modal);
            };
            
            document.getElementById('trialReminderCloseBtn').onclick = () => {
                document.body.removeChild(modal);
            };
            
            // 阻止点击背景关闭（需要用户确认）
            modal.onclick = (e) => {
                e.stopPropagation();
            };
        }

        // 显示欢迎弹窗
        showWelcomeModal() {
            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999999;
                display: flex;
                justify-content: center;
                align-items: center;
                font-family: Arial, sans-serif;
            `;
            
            modal.innerHTML = `
                <div style="
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    max-width: 500px;
                    text-align: center;
                    position: relative;
                ">
                    <h2 style="color: #333; margin-bottom: 20px; font-size: 24px;">🎉 欢迎使用 OZON 销量助手</h2>
                    <div style="margin-bottom: 20px; line-height: 1.6; color: #666;">
                        <p style="margin-bottom: 15px;">感谢您选择 OZON 销量助手插件！</p>
                        <p style="margin-bottom: 15px;">本插件将帮助您：</p>
                        <ul style="text-align: left; margin: 15px 0; padding-left: 20px;">
                            <li>📊 实时监控商品销量数据</li>
                            <li>📈 分析销售趋势和表现</li>
                            <li>🎯 优化商品推广策略</li>
                            <li>💡 提供专业的销售建议</li>
                        </ul>
                        <p style="margin-top: 20px; font-weight: bold; color: #e74c3c;">当前版本：30天试用版本</p>
                        <div style="text-align: center; margin-top: 20px; font-size: 14px; color: #999;">
                            <p>此欢迎提示将在 <span id="welcomeCountdown">5</span> 秒后自动关闭</p>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // 自动关闭倒计时
            let countdown = 5;
            const countdownElement = document.getElementById('welcomeCountdown');
            const countdownInterval = setInterval(() => {
                countdown--;
                if (countdownElement) {
                    countdownElement.textContent = countdown;
                }
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    if (document.body.contains(modal)) {
                        document.body.removeChild(modal);
                    }
                }
            }, 1000);
            
            // 点击背景关闭
            modal.onclick = (e) => {
                if (e.target === modal) {
                    clearInterval(countdownInterval);
                    if (document.body.contains(modal)) {
                        document.body.removeChild(modal);
                    }
                }
            };
        }

        // Initialize the plugin
        init() {
            console.log('🔧 开始初始化插件功能...');
            
            // 欢迎弹窗在短期内（10分钟）只显示一次，不受页面刷新影响
            const currentTime = this.getSystemTimestamp();
            const lastWelcomeTime = localStorage.getItem('ozon_welcome_last_shown');
            const welcomeInterval = 10 * 60 * 1000; // 10分钟
            
            if (!lastWelcomeTime || (currentTime - parseInt(lastWelcomeTime)) > welcomeInterval) {
                console.log('📢 显示欢迎弹窗');
                this.showWelcomeModal();
                localStorage.setItem('ozon_welcome_last_shown', currentTime.toString());
            } else {
                console.log('📢 欢迎弹窗在10分钟内已显示过，跳过');
            }
            
            // 检查试用期（包含自动显示过期弹窗的逻辑）
            if (!this.checkTrialPeriod()) {
                console.log('❌ 试用期已过期，插件功能将被禁用');
                return false;
            }
            
            console.log('✅ 试用期检查通过，继续初始化...');
            
            if (this.setupAutoRedirect()) {
                console.log('🔄 设置了自动重定向');
                return false;
            }
            
            console.log('🛠️ 创建拦截器和模态框...');
            this.createXHRInterceptor();
            this.createFetchInterceptor();
            this.createCommonModal();
            
            console.log('🎉 插件初始化完成！');
        }

        // Check if we need to redirect from graphs page
        checkAnalyticsGraphs() {
            if (!new RegExp('/analytics/graphs', 'i').test(location.pathname)) {
                return false;
            }
            
            const blurredCells = document.querySelectorAll('td.index___td_halign_right_1Pqeg.index___td_uUKmN.index__has-background_tOH5o span.styles_total_wyroi.styles_blurredCell_5Qe0j');
            if (blurredCells.length > 0) {
                console.log('检测到OZON卖家后台分析报表高斯模糊单元格');
                sessionStorage.setItem('sf_ozon_from_graphs', 'true');
                sessionStorage.setItem('sf_ozon_original_path', location.pathname);
                history.pushState(null, '', 'https://seller.ozon.ru/app/analytics');
                location.search = '?sf_ozon_force_refresh=' + Date.now();
                return true;
            }
            return false;
        }

        // Check competitive position page
        checkCompetitiveCells() {
            if (!new RegExp('/analytics/what-to-sell/competitive-position', 'i').test(location.pathname)) {
                return false;
            }
            
            console.log('进入OZON卖家后台竞争地位页面');
            sessionStorage.setItem('sf_ozon_from_graphs', 'true');
            sessionStorage.setItem('sf_ozon_original_path', location.pathname);
            history.pushState(null, '', 'https://seller.ozon.ru/app/analytics/what-to-sell/categories-comparison');
            location.search = '?sf_ozon_force_refresh=' + Date.now();
            return true;
        }

        // Setup auto redirect logic
        setupAutoRedirect() {
            if (new RegExp('/analytics/graphs', 'i').test(location.pathname)) {
                console.log('开始检查分析报表模糊单元格');
                return this.checkAnalyticsGraphs();
            }
            
            if (new RegExp('/analytics$', 'i').test(location.pathname) && 
                location.search.includes('sf_ozon_force_refresh')) {
                console.log('已在OZON卖家后台分析页面，安装拦截器');
                this.createXHRInterceptor();
                this.createFetchInterceptor();
                return true;
            }
            
            return false;
        }

        // Create XHR interceptor
        createXHRInterceptor() {
            const originalXHR = window.XMLHttpRequest;
            const self = this;

            class InterceptedXHR extends originalXHR {
                constructor() {
                    super();
                    this.ozUrl = '';
                    this.ozIntercepted = false;
                }

                open(method, url) {
                    this.ozUrl = url;
                    return super.open(method, url);
                }

                send(data) {
                    const interceptPatterns = [
                        new RegExp('/premium/status', 'i'),
                        new RegExp('/statistics/data', 'i'),
                        new RegExp('/graph/data', 'i'),
                        new RegExp('/analytics/graphs', 'i'),
                        new RegExp('/analytics$', 'i'),
                        new RegExp('seller-analytics/premium/status', 'i')
                    ];

                    const shouldIntercept = interceptPatterns.some(pattern => pattern.test(this.ozUrl));

                    if (shouldIntercept) {
                        console.log('拦截URL:', this.ozUrl);
                        this.ozIntercepted = true;
                        
                        const mockResponse = self.refactorResponse(this.ozUrl);
                        
                        // Mock the response
                        Object.defineProperties(this, {
                            'responseText': { value: mockResponse },
                            'response': { value: mockResponse },
                            'status': { value: 200 },
                            'statusText': { value: 'OK' },
                            'readyState': { 
                                get: () => this.ozIntercepted ? 4 : super.readyState 
                            }
                        });

                        // Trigger events asynchronously
                        Promise.resolve().then(() => {
                            if (typeof this.onreadystatechange === 'function') {
                                this.onreadystatechange(new Event('readystatechange'));
                            }
                            if (typeof this.onload === 'function') {
                                this.onload(new Event('load'));
                            }
                            this.dispatchEvent(new Event('load'));
                            this.dispatchEvent(new Event('loadend'));
                        });

                        // Handle premium status redirect
                        if (new RegExp('seller-analytics/premium/status', 'i').test(this.ozUrl)) {
                            setTimeout(() => {
                                history.pushState(null, '', 'https://seller.ozon.ru/app/analytics/graphs');
                                window.dispatchEvent(new PopStateEvent('popstate'));
                                setTimeout(() => {
                                    const customEvent = new CustomEvent('sf-ozon-extension-trigger');
                                    window.dispatchEvent(customEvent);
                                }, 100);
                            }, 1000);
                        }
                    }

                    return super.send(data);
                }
            }

            try {
                window.XMLHttpRequest = InterceptedXHR;
                if (window.XMLHttpRequest.prototype !== InterceptedXHR.prototype) {
                    Object.setPrototypeOf(window.XMLHttpRequest, InterceptedXHR);
                }
                console.log('XHR深度拦截安装成功');
                return true;
            } catch (error) {
                console.log('XHR拦截失败:', error);
                return false;
            }
        }

        // Create Fetch interceptor
        createFetchInterceptor() {
            const originalFetch = window.fetch;
            const self = this;

            window.fetch = async (input, init) => {
                const url = (input instanceof Request ? input.url : input) || '';
                
                const interceptPatterns = [
                    new RegExp('/premium/status', 'i'),
                    new RegExp('seller-analytics/premium/status', 'i'),
                    new RegExp('/graph/data', 'i'),
                    new RegExp('/analytics/graphs', 'i'),
                    new RegExp('/analytics$', 'i'),
                    new RegExp('seller-analytics/premium/status', 'i')
                ];

                const shouldIntercept = interceptPatterns.some(pattern => pattern.test(url));

                if (shouldIntercept) {
                    console.log('深度拦截Fetch Url:', url);
                    return new Response(
                        JSON.stringify(self.refactorResponse(url)),
                        {
                            status: 200,
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Intercepted': 'true'
                            }
                        }
                    );
                }

                try {
                    return await originalFetch(input, init);
                } catch (error) {
                    console.log('Fetch请求失败:', error);
                    throw error;
                }
            };

            console.log('Fetch深度拦截安装成功');
            return true;
        }

        // Generate mock response data
        refactorResponse(url) {
            const baseResponse = {
                status: 'grace_good',
                is_premium: true,
                is_premium_plus: true,
                isAnalyst: true,
                subscription: {
                    current: 'PREMIUM_PLUS',
                    available: ['PREMIUM_PLUS'],
                    grace_period_end_at: new Date(Date.now() + 157680000000).toISOString()
                },
                features: {
                    analytics: 'full',
                    marketing: 'full',
                    api: 'FULL',
                    graphs: 'full',
                    reports: 'full',
                    statistics: 'full',
                    recommendations: 'full'
                }
            };

            if (new RegExp('/statistics/data', 'i').test(url)) {
                return {
                    ...baseResponse,
                    dataPoints: Array.from({ length: 15 }, (_, index) => ({
                        id: 'metric_' + index,
                        value: Math.floor(Math.random() * 1000),
                        trend: Math.random() > 0.5 ? 'up' : 'down',
                        change: Math.floor(Math.random() * 100)
                    })),
                    hasAccess: true,
                    accessLevel: 'full_access'
                };
            }

            if (new RegExp('/analytics/graphs', 'i').test(url) || 
                new RegExp('/analytics$', 'i').test(url)) {
                return {
                    ...baseResponse,
                    graphsAccess: true,
                    dataSets: ['sales', 'traffic', 'conversion'],
                    timeRanges: ['day', 'week', 'month']
                };
            }

            return baseResponse;
        }

        // Create common modal
        createCommonModal() {
            const modal = $('<div>', {
                'class': 'modal fade',
                'id': 'common-modal',
                'tabindex': '-1',
                'role': 'dialog',
                'aria-labelledby': 'common-modal'
            }).append(
                $('<div>', { 'class': 'modal-dialog modal-dialog-centered' }).append(
                    $('<div>', { 'class': 'modal-content', 'style': 'border-top: none;' }).append(
                        $('<div>', { 'class': 'modal-header', 'style': 'line-height: 2' }).append(
                            $('<button>', {
                                'type': 'button',
                                'class': 'close',
                                'data-dismiss': 'modal',
                                'aria-hidden': true,
                                'style': 'border-bottom: none;'
                            }).html('&times;'),
                            $('<h2>', { 'class': 'modal-title text-center', 'style': 'font-size: 35px' })
                        ),
                        $('<div>', { 'class': 'modal-body', 'style': 'text-start' }),
                        $('<div>', { 'class': 'modal-footer', 'style': 'line-height: 2;' })
                    )
                )
            );

            $('body').append(modal);
        }

        // Show success modal
        showSuccessModal(title, content, footer) {
            const modal = $('#common-modal');
            modal.find('.modal-title')
                .removeClass('text-start')
                .addClass('text-center')
                .html(title);
            modal.find('.modal-body')
                .removeClass('text-start')
                .addClass('text-center')
                .html(content);
            modal.find('.modal-footer')
                .removeClass('text-end')
                .addClass('text-center')
                .html(footer);
            modal.modal('show');
        }

        // Show modal tips
        showModalTips(title, content, footer) {
            const modal = $('#common-modal');
            modal.find('.modal-title')
                .removeClass('text-center')
                .addClass('text-start')
                .html(title);
            modal.find('.modal-body')
                .removeClass('text-center')
                .addClass('text-start')
                .html(content);
            modal.find('.modal-footer')
                .removeClass('text-center')
                .addClass('text-end')
                .html(footer);
            modal.modal('show');
        }

        // Show modal content
        showModalContent() {
            const fromGraphs = sessionStorage.getItem('sf_ozon_from_graphs');
            const hasRefresh = location.search.includes('sf_ozon_force_refresh');
            
            if (!hasRefresh || !fromGraphs) {
                console.log('非拦截器访问，不弹窗');
                return;
            }

            const title = '';
            const content = '';
            const footer = '<button class="btn btn-primary modal-action">确定</button>';
            
            this.showSuccessModal(title, content, footer);
            
            $('.modal-action').off('click').on('click', function() {
                $('#common-modal').modal('hide');
                history.pushState(null, '', 'https://seller.ozon.ru/app/analytics/graphs');
                window.dispatchEvent(new PopStateEvent('popstate'));
                setTimeout(() => {
                    const customEvent = new CustomEvent('sf-ozon-extension-trigger');
                    window.dispatchEvent(customEvent);
                }, 100);
            });
        }

        // Start the plugin
        start() {
            this.init();
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', this.showModalContent, { once: true });
            }
        }
    }

    // 多种方式确保插件正确初始化
    function initializePlugin() {
        console.log('🚀 开始初始化OZON销量助手插件...');
        try {
            const ozonAssistant = new OzonSalesAssistant();
            
            console.log('✅ 插件初始化成功');
        } catch (error) {
            console.error('❌ 插件初始化失败:', error);
            // 延迟重试
            setTimeout(initializePlugin, 1000);
        }
    }

    // 方式1: DOM内容加载完成时初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializePlugin);
    } else {
        // DOM已经加载完成，直接初始化
        initializePlugin();
    }

    // 方式2: 如果jQuery可用，也使用jQuery ready
    if (typeof $ !== 'undefined') {
        $(function() {
            console.log('📚 jQuery已就绪，确保插件初始化');
            // 检查插件是否已经初始化，避免重复初始化
            if (!window.ozonAssistantInitialized) {
                initializePlugin();
            }
        });
    }

    // 方式3: 页面完全加载后的备用初始化
    window.addEventListener('load', function() {
        console.log('🌐 页面完全加载，检查插件状态');
        setTimeout(() => {
            if (!window.ozonAssistantInitialized) {
                console.log('🔄 备用初始化启动');
                initializePlugin();
            }
        }, 500);
    });

})();